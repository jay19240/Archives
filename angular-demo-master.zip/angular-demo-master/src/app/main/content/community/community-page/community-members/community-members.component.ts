import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-community-members',
  templateUrl: './community-members.component.html',
  styleUrls: ['./community-members.component.scss']
})
export class CommunityMembersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
