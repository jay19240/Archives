import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meet-place',
  templateUrl: './meet-place.component.html',
  styleUrls: ['./meet-place.component.scss']
})
export class MeetPlaceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
