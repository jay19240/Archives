import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-suggest-tags',
  templateUrl: './suggest-tags.component.html',
  styleUrls: ['./suggest-tags.component.scss']
})
export class SuggestTagsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
