import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-community-activities',
  templateUrl: './community-activities.component.html',
  styleUrls: ['./community-activities.component.scss']
})
export class CommunityActivitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
