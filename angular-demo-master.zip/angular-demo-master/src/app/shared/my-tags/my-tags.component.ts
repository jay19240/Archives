import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-tags',
  templateUrl: './my-tags.component.html',
  styleUrls: ['./my-tags.component.scss']
})
export class MyTagsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
