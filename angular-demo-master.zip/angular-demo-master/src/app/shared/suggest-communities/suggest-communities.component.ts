import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-suggest-communities',
  templateUrl: './suggest-communities.component.html',
  styleUrls: ['./suggest-communities.component.scss']
})
export class SuggestCommunitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
